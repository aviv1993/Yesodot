import System.DB.ProjectDbImplement;
import System.DB.UserDbImplement;
import System.Logic.DepartmentPrinter;
import System.Logic.ProjectManager;
import System.Logic.ProjectManagment;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args){
    }

}
