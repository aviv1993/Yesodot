package System.Logic;

import System.Logic.Entities.Project;

public interface Observer {
    void update(Project project);
}
