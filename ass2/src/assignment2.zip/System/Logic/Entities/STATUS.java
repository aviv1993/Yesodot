package System.Logic.Entities;

public enum STATUS {
    Check,Confirmed,Reject,Projgress;
}
