package acptTests.auxiliary;

public class DBSuggestedProjectInfo {
    public String firstName;
    public String lastName;
	public String phone;
	public String email;
    public String organization;
    public String projectName;
    public String description;
    public int numberOfHours;
}